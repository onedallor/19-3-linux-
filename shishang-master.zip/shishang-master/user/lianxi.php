<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" type="text/css" href="../CSS/head.css" />
<title>食尚</title>
<style>
#main{
	width: 100%;
	height: 1000px;
	background: #F2F2F2;
}
.kuang{
	width: 90%;
	height: 580px;
	float: left;
	margin: 15% 0 0 5%;
	background: url("../images/lianxi/bg.jpeg");
	background-size: 100% 100%;
}
.lianxi_con{
	width: 40%;
	height: 450px;
	margin: 4% 0 0 33%;
	float: left;
}
</style>
</head>
<body>
<?php
	require_once("head.php");
?>

<div id="main">
	<div class="kuang">
		<div class="lianxi_con">
			<p style="font-size: 28px;color:white; margin-top:10%;">食尚餐饮有限公司</p>
			<p style="font-size: 24px;color:#C9C9C9;margin:21% 0 0 0;line-height:60px;">加盟热线：0898-123-4567<br />招纳贤士 :0898-987654321<br />地址：海南省海口市桂林洋大学城琼台师范学院<br />邮箱：123456789@163.com</p>
		</div>
	</div>
</div>




<?php
    require_once("bottom.php")
?>
</body>
</html>